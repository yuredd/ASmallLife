ASmallLife
==========

a collaborative game