#!/bin/sh
java -cp .:bin/:libs/* com.yuredd.asmalllife.ASmallLifeDesktop
