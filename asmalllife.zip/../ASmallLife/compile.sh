#!/bin/sh
javac -d bin -cp bin/:libs/* src/*.java
